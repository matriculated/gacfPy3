# -*- coding: utf-8 -*-
DBREG = {}
PROCREG = {}
def register(name, uri):
    if not name in DBREG:
        try:
            conn = DAL(uri, pool_size = 1, migrate_enabled = False, check_reserved = ['all'])
            DBREG[name] = conn
        except Exception as e:
            DBREG[name] = e

def registerProc(name, uri):
    if not name in DBREG:
        try:
            db = DAL(uri, pool_size = 1, migrate_enabled = False, check_reserved = ['all'])
            # db.conn()
            PROCREG[name] = conn
        except Exception as e:
            PROCREG[name] = e

import os.path 
x=os.getcwd()+ '\\applications\\' +request.application+'\models\database_registry.py.bak'
outfile=os.getcwd()+ '\\applications\\' +request.application+'\models\database_registry.py.out'

from pydal import DAL, Field
db=DAL('mssql4://BuildDbAdmin:Alt0ids76@localhost/master')
results=db.executesql('select * from sys.databases')
with open(outfile, 'w') as f:
    for row in results:
        register(row.name, 'mssql4://BuildDbAdmin:Alt0ids76@localhost/' + row.name)
