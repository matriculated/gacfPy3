#!/usr/bin/env python3
from pydal import DAL, Field
import sys

sys.path.append('../modules')
import schemaUtilities
# reload(schemaUtilities)
procname="prcAgeNameInput"
expected=[('PyodbcDb', 'prcAgeNameInput', '@age', 'IN', 'int', None), ('PyodbcDb', 'prcAgeNameInput', '@name', 'IN', 'nvarchar', 50)]
db = DAL('mssql://Driver={SQL Server};Server=localhost;Database=PyodbcDb;Trusted_Connection=yes;')
results=db.executesql("select SPECIFIC_CATALOG, SPECIFIC_NAME, PARAMETER_NAME, PARAMETER_MODE, DATA_TYPE, CHARACTER_MAXIMUM_LENGTH from information_schema.PARAMETERS WHERE SPECIFIC_NAME = '" + procname  + "' ORDER BY SPECIFIC_NAME, ORDINAL_POSITION")
print("direct retrieval of stored procedure constraints for ")
print(results)
# actualx=[]
print(schemaUtilities.schemaUtilities.getProcConstraints(procname))
actualx=schemaUtilities.schemaUtilities.getProcConstraints(procname)
print(len(expected) == len(actualx))
print(sorted(expected)[0][0] == sorted(actualx)[0][0])
print(sorted(expected)[0][1] == sorted(actualx)[0][1])
print(sorted(expected)[1][0] == sorted(actualx)[1][0])
print(sorted(expected)[1][1] == sorted(actualx)[1][1])
print(len(expected) == len(actualx) and sorted(expected) == sorted(actualx))
# You get the idea on how to compare lists and tuples