# -*- coding: utf-8 -*-
from pydal import DAL, Field
import os.path 
DBREG = {}
def registerx(name, uri):
    if not name in DBREG:
        try:
            conn = DAL(uri, pool_size = 1, migrate_enabled = False, check_reserved = ['all'])
            DBREG[name] = conn
        except Exception as e:
            DBREG[name] = e

# @auth.requires_login()
def indexx():

    x=os.getcwd()+ '\\applications\\' + request.application+'\models\database_registry.py.bak'
    outfile=os.getcwd()+ '\\applications\\' +request.application+'\models\database_registry.py.out'

    db=DAL('mssql4://BuildDbAdmin:Alt0ids76@localhost/master')
    results=db.executesql('select * from sys.databases')
    with open(outfile, 'w') as f:
        for row in results:
            # f.write("%s\n" % str(row.name))
            # register('ApplicationConfiguration', 'mssql4://BuildDbAdmin:Alt0ids76@localhost/ApplicationConfiguration')
            registerx(row.name, 'mssql4://BuildDbAdmin:Alt0ids76@localhost/' + row.name)

    return DBREG

def dbschema():
    return DBREG


def index():
    indexx()
    keys = []
    for k,v in list(DBREG.items()):
        if not isinstance(v, Exception):
            keys.append(k)
    return dict(databaseNames = keys)
#END def index
