# -*- coding: utf-8 -*-
import os.path 
import sys
import pyodbc
sys.path.append('../modules')
import schemaUtilities
from pydal import DAL, Field

def getDbList():
    db=DAL('mssql://Driver={SQL Server};Server=localhost;Database=master;Trusted_Connection=yes;')
    results=db.executesql('select name from sys.databases')
    appdbs = []
    sysdbs = ['master', 'tempdb', 'model', 'msdb']
    for i in range(len(results)):
        results[i] = results[i].name.encode('ascii','ignore')
        if results[i] not in sysdbs:
            appdbs.append(results[i])
    return appdbs


def index():
    # storedProcedures={"A":"AAAA", "B":"BBBB"}
    # return locals

    # db=DAL('mssql://Driver={SQL Server};Server=localhost;Database=master;Trusted_Connection=yes;')
    # results=db.executesql('select name from sys.databases')
    # appdbs = []
    # sysdbs = ['master', 'tempdb', 'model', 'msdb']
    # for i in range(len(results)):
    #     results[i] = results[i].name.encode('ascii','ignore')
    #     if results[i] not in sysdbs:
    #         appdbs.append(results[i])
    appdbs=getDbList()
    # with open(outfile, 'w') as f:
        # for row in results:
            ## f.write("%s\n" % str(row.name))
            # register(row.name, 'mssql4://BuildDbAdmin:Alt0ids76@localhost/' + row.name)
    # return results
    # return DBREG
    # return storedProcedures
    # import pyodbc
    procName=[]
    for i in range(len(appdbs)):
        db=appdbs[i]
        cnxn = pyodbc.connect(r'Driver={SQL Server};Server=localhost;Database='+ db + r';Trusted_Connection=yes;')
        cursor = cnxn.cursor()
        cursor.execute("SELECT * FROM information_schema.routines WHERE ROUTINE_TYPE = 'PROCEDURE'")
        while 1:
            row = cursor.fetchone()
            if not row:
                break
            procName.append(db + "::" + row.ROUTINE_NAME.encode('ascii','ignore'))
    return locals()

def edit():
    dbname = request.get_vars.get('dbname', None)
    # if dbname not in DBREG:
        # redirect(URL(c = 'database', f = 'index'))
    # database = DBREG[dbname]
    procname = request.get_vars.get('procname',None)
    # if not traversalValidators.traversalValidators.validateTableName(database, table_name):
        # redirect(URL(c = 'database', f = 'view', vars = dict(dbname = dbname)))
    # print("Stored_Proc " + dbname + "::" + procname)    
    # constraints = schemaUtilities.schemaUtilities.getProcConstraints(procname)
    # constraints=schemaUtilities.getProcConstraints(procname)
    db = DAL('mssql://Driver={SQL Server};Server=localhost;Database=PyodbcDb;Trusted_Connection=yes;')
    constraints=db.executesql("select SPECIFIC_CATALOG, SPECIFIC_NAME, PARAMETER_NAME, PARAMETER_MODE, DATA_TYPE, CHARACTER_MAXIMUM_LENGTH from information_schema.PARAMETERS WHERE SPECIFIC_NAME = '" + procname  + "' ORDER BY SPECIFIC_NAME, ORDINAL_POSITION")
    for i in range(len(constraints)):
        for e in range(len(constraints[0])):
            if constraints[i][e] is not None:
               constraints[i][e] = str(constraints[i][e]).encode('ascii','ignore')
    print(constraints)
    return locals()    
